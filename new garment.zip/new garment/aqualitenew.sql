-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2020 at 03:08 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aqualitenew`
--

-- --------------------------------------------------------

--
-- Table structure for table `addproduction`
--
CREATE DATABASE aqualitenew;
USE aqualitenew;

CREATE TABLE `addproduction` (
  `productid` varchar(30) NOT NULL,
  `productname` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addproduction`
--

INSERT INTO `addproduction` (`productid`, `productname`) VALUES
('P10', 'shirt'),
('P11', 'trouser'),
('P12', 'Tshirt'),
('P14', 'Shoes'),
('P13', 'Denim'),
('P15', 'Hat'),
('P16', 'Belt');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_no` varchar(10) NOT NULL,
  `sec_id` varchar(10) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL,
  `job_type` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_no`, `sec_id`, `name`, `contact_no`, `email`, `address`, `job_type`) VALUES
('e01', 's10', 'nimal', 776611456, 'nimal@gmail.com', 'colombo', 'Director'),
('e02', 's11', 'ruwan', 776615676, 'ruwan@gmail.com', 'kandy', 'Supervisor'),
('e03', 's12', 'saduni', 776611245, 'saduni@gmail.com', 'mathara', 'Supervisor'),
('e04', 's13', 'sadun', 712378567, 'sadun@gmail.com', 'galle', 'Worker'),
('e05', 's10', 'kasun', 774201897, 'kasun@gmail.com', 'colombo', 'Select Employee Type'),
('e06', 's11', 'dasun', 774201897, 'kasun@gmail.com', 'colombo', 'Supervisor');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_ID` varchar(5) DEFAULT NULL,
  `elec_bill` varchar(10) DEFAULT NULL,
  `water_bill` varchar(10) DEFAULT NULL,
  `trans_bill` varchar(10) DEFAULT NULL,
  `main_bill` varchar(10) DEFAULT NULL,
  `tot_bill` varchar(10) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `secID` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_ID`, `elec_bill`, `water_bill`, `trans_bill`, `main_bill`, `tot_bill`, `date`, `secID`) VALUES
('R10', '1000', '2356', '132', '3468', '6956.0', 'January ', 'S10'),
('R11', '5372', '2223', '323', '3334', '11252.0', 'January ', 'S11');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `sal_id` varchar(10) NOT NULL,
  `emp_id` varchar(10) NOT NULL,
  `basic_sal` int(11) DEFAULT NULL,
  `ot_ammount` int(11) DEFAULT NULL,
  `allowance` int(11) DEFAULT NULL,
  `attendance_all` int(11) DEFAULT NULL,
  `transport_chrg` int(11) DEFAULT NULL,
  `etf` int(11) DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `net_salary` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`sal_id`, `emp_id`, `basic_sal`, `ot_ammount`, `allowance`, `attendance_all`, `transport_chrg`, `etf`, `month`, `net_salary`) VALUES
('s0001', 'e01', 100000, 1800, 8000, 0, 2000, 4000, 'January', 103800),
('S0002', 'e02', 80000, 2550, 4000, 0, 2000, 3000, 'January', 81550),
('S0003', 'e03', 50000, 3300, 3500, 4500, 1500, 2500, 'January', 57300),
('S0004', 'e04', 30000, 5100, 4000, 5000, 1000, 1500, 'January', 41600),
('S0005', 'e03', 10000, 750, 3500, 4500, 1500, 2500, 'February', 14750);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `saleid` int(11) NOT NULL,
  `productid` varchar(30) DEFAULT NULL,
  `productname` varchar(30) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` varchar(8) DEFAULT NULL,
  `month` varchar(15) DEFAULT NULL,
  `secid` varchar(10) DEFAULT NULL,
  `total` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`saleid`, `productid`, `productname`, `qty`, `price`, `month`, `secid`, `total`) VALUES
(1, 'p10', 'shirt', 10, '100', 'january', 's11', '1000'),
(2, 'P11', 'trouser', 100, '150.0', 'January', 's11', '15000.0'),
(3, 'P14', 'Shoes', 120, '150.0', 'December', 's11', '18000.0'),
(4, 'P15', 'Hat', 100, '567.0', 'April', 's11', '56700.0'),
(5, 'P16', 'Belt', 150, '100.0', 'February', 's11', '15000.0'),
(6, 'P15', 'Hat', 1290, '220.0', 'June', 's11', '283800.0');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `sectionid` varchar(20) NOT NULL,
  `sectionname` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`sectionid`, `sectionname`) VALUES
('s10', 'Administrator'),
('s11', 'Production'),
('s13', 'NonAcadamic'),
('s12', 'Maintaining');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `password`, `email`) VALUES
('u1', 'kaveesha', 'kavee99', '123#', 'kaveesha0831@gmail.com'),
('u2', 'ravindu', 'ravi97', '789@', 'ravindu@gmail.com'),
('u3', 'danush', 'danu', '963&', 'danu@gmail.com'),
('u4', 'aseni', 'aaa99', '145', 'aseni@gmail.com'),
('u5', 'raveesha', 'ravee', '456', 'ravee00@gmail.com'),
('u6', 'kamal', 'kk99', '963%', 'kamal@gmail.com'),
('u7', 'shanilka', 'admin', 'admin', 'randimalperera62@gmail.com'),
('u8', 'sanjeewa', 'san', 'sanjeewa', 'sanjeewa406@gmail.com'),
('u9', 'ran', 'randi', 'randi', 'randi@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addproduction`
--
ALTER TABLE `addproduction`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_no`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD KEY `secID` (`secID`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`sal_id`,`emp_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`saleid`),
  ADD KEY `productid` (`productid`),
  ADD KEY `secid` (`secid`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`sectionid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `saleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
